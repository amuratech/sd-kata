package com.kylas.parkingapplication;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ParkingapplicationApplicationTests {


}
