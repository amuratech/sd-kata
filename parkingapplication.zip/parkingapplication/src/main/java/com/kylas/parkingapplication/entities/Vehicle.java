package com.kylas.parkingapplication.entities;

public class Vehicle {

    private String vehicleNo;

    public Vehicle(String vehicleNo) {
        this.vehicleNo = vehicleNo;
    }


    public String getVehicleNo() {
        return vehicleNo;
    }

    public Vehicle() {

    }

}
